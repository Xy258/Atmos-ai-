import { useMemo, useState } from "react";
import {
  Bell,
  CalendarDays,
  CloudDrizzle,
  CloudSun,
  Droplets,
  Gauge,
  MapPin,
  Menu,
  Moon,
  Navigation,
  Search,
  Sun,
  Sunrise,
  Wind,
} from "lucide-react";

type City = { name: string; country: string; temp: number; status: string; accent: string };

const cities: City[] = [
  { name: "San Francisco", country: "California, US", temp: 18, status: "Partly cloudy", accent: "#e8b84b" },
  { name: "New York", country: "New York, US", temp: 24, status: "Bright and clear", accent: "#d77b56" },
  { name: "London", country: "England, UK", temp: 13, status: "Light showers", accent: "#71aeb1" },
];

const hours = [
  { time: "Now", temp: 18, rain: 8, Icon: CloudSun },
  { time: "12 PM", temp: 19, rain: 10, Icon: Sun },
  { time: "1 PM", temp: 20, rain: 12, Icon: Sun },
  { time: "2 PM", temp: 20, rain: 16, Icon: CloudSun },
  { time: "3 PM", temp: 19, rain: 20, Icon: CloudSun },
  { time: "4 PM", temp: 18, rain: 22, Icon: CloudDrizzle },
  { time: "5 PM", temp: 17, rain: 24, Icon: CloudDrizzle },
  { time: "6 PM", temp: 16, rain: 19, Icon: Moon },
];

const week = [
  ["Today", "Jun 18", 20, 14, CloudSun, "Partly cloudy"],
  ["Thu", "Jun 19", 22, 15, Sun, "Clear skies"],
  ["Fri", "Jun 20", 19, 13, CloudDrizzle, "Passing showers"],
  ["Sat", "Jun 21", 21, 14, CloudSun, "Mostly sunny"],
  ["Sun", "Jun 22", 23, 16, Sun, "Clear skies"],
];

export default function AtmosWeatherTimeline() {
  const [city, setCity] = useState(cities[0]);
  const [active, setActive] = useState("Today");
  const [selectedHour, setSelectedHour] = useState(0);
  const [searchOpen, setSearchOpen] = useState(false);
  const selected = hours[selectedHour];
  const progress = useMemo(() => `${Math.min(92, 10 + selectedHour * 11)}%`, [selectedHour]);

  return (
    <div className="min-h-[100dvh] overflow-x-hidden" style={{ background: "#f2efe8", color: "#25393c", fontFamily: "'DM Sans', sans-serif" }}>
      <div className="mx-auto flex min-h-[100dvh] max-w-[1500px]">
        <aside className="hidden w-[238px] shrink-0 flex-col justify-between border-r px-7 py-8 lg:flex" style={{ borderColor: "#d8d9d0", background: "#e7ebe4" }}>
          <div>
            <div className="mb-12 flex items-center gap-3">
              <div className="grid h-9 w-9 -rotate-6 place-items-center rounded-[12px_12px_12px_3px]" style={{ background: "#d99e3d", color: "#25393c" }}><CloudSun size={20} /></div>
              <span className="text-[23px] font-bold tracking-[-.08em]">atmos</span>
            </div>
            <p className="mb-3 px-2 font-mono text-[9px] uppercase tracking-[.2em]" style={{ color: "#7b8885" }}>Your weather map</p>
            <nav className="space-y-1">
              {[
                [Sun, "Today"], [CalendarDays, "The week"], [MapPin, "Saved places"],
              ].map(([Icon, label]) => (
                <button key={label as string} onClick={() => setActive(label as string)} className="flex w-full items-center gap-3 rounded-xl px-3 py-3 text-left text-[13px] transition hover:translate-x-1" style={{ background: active === label ? "#d7dfd7" : "transparent", color: active === label ? "#254e51" : "#65726e" }}>
                  <Icon size={17} /><span>{label as string}</span>{active === label && <span className="ml-auto h-1.5 w-1.5 rounded-full" style={{ background: "#d99e3d" }} />}
                </button>
              ))}
            </nav>
            <p className="mb-3 mt-12 px-2 font-mono text-[9px] uppercase tracking-[.2em]" style={{ color: "#7b8885" }}>Pinned locations</p>
            <div className="space-y-1">
              {cities.map((item) => <button key={item.name} onClick={() => setCity(item)} className="flex w-full items-center justify-between rounded-xl px-3 py-3 text-left text-[12px] transition hover:bg-[#d7dfd7]" style={{ color: city.name === item.name ? "#254e51" : "#65726e" }}><span>{item.name}</span><span className="font-mono text-[10px]">{item.temp}°</span></button>)}
            </div>
          </div>
          <div className="border-t pt-5 font-mono text-[9px] leading-5" style={{ borderColor: "#d2d8d1", color: "#81908a" }}><span className="mr-2 inline-block h-1.5 w-1.5 rounded-full bg-[#70a782]" />Forecasts are live<br /><span className="pl-3">Open-Meteo · updated 2m ago</span></div>
        </aside>

        <main className="min-w-0 flex-1">
          <header className="flex items-center gap-3 border-b px-5 py-4 sm:px-8 lg:px-12" style={{ borderColor: "#d8d9d0", background: "rgba(242,239,232,.82)" }}>
            <button className="grid h-9 w-9 place-items-center rounded-lg border lg:hidden" style={{ borderColor: "#d5d8d1" }} aria-label="Open menu"><Menu size={18} /></button>
            <div className="flex items-center gap-2 lg:hidden"><CloudSun size={21} style={{ color: "#d99e3d" }} /><span className="font-bold tracking-[-.07em]">atmos</span></div>
            <div className="relative ml-auto w-full max-w-[350px]">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2" size={15} style={{ color: "#8a9691" }} />
              <input onFocus={() => setSearchOpen(true)} onBlur={() => setTimeout(() => setSearchOpen(false), 150)} className="h-10 w-full rounded-xl border bg-[#f7f5ef] pl-10 pr-4 text-[12px] outline-none focus:border-[#7ba6a3]" style={{ borderColor: "#d5d8d1" }} placeholder="Search another place" />
              {searchOpen && <div className="absolute left-0 right-0 top-12 z-10 rounded-xl border bg-[#f7f5ef] p-1 shadow-lg" style={{ borderColor: "#d5d8d1" }}>{cities.map((item) => <button onMouseDown={() => setCity(item)} className="block w-full rounded-lg px-3 py-2 text-left text-[12px] hover:bg-[#e7ebe4]" key={item.name}>{item.name}<small className="ml-2 text-[#8a9691]">{item.country}</small></button>)}</div>}
            </div>
            <button className="grid h-10 w-10 shrink-0 place-items-center rounded-xl border" style={{ borderColor: "#d5d8d1" }} aria-label="Notifications"><Bell size={16} /></button>
          </header>

          <div className="px-5 pb-16 pt-8 sm:px-8 lg:px-12 lg:pt-12">
            <div className="mb-8 flex flex-wrap items-end justify-between gap-5">
              <div><p className="mb-2 font-mono text-[9px] uppercase tracking-[.2em]" style={{ color: "#7b8885" }}>Tuesday, June 18 · 11:42 AM local time</p><h1 className="text-[42px] font-bold leading-[.92] tracking-[-.08em] sm:text-[58px]">{city.name}</h1><p className="mt-3 flex items-center gap-1.5 text-[12px]" style={{ color: "#74817d" }}><MapPin size={13} />{city.country} <span className="mx-1">·</span> <span className="text-[#4f8786]">Live conditions</span></p></div>
              <button className="flex items-center gap-2 rounded-full border px-4 py-2 text-[11px]" style={{ borderColor: "#d5d8d1", background: "#f7f5ef" }}><Navigation size={13} />Use my location</button>
            </div>

            <section className="grid gap-4 xl:grid-cols-[1.12fr_.88fr]">
              <div className="relative min-h-[290px] overflow-hidden rounded-[26px] p-7 text-[#f6f0df] sm:p-9" style={{ background: "linear-gradient(140deg,#24575d 0%,#3b7473 58%,#789b8d 100%)" }}>
                <div className="absolute -right-20 -top-24 h-72 w-72 rounded-full border border-[#dfe5c4]/20 shadow-[0_0_0_28px_rgba(223,229,196,.04),0_0_0_56px_rgba(223,229,196,.04)]" />
                <div className="relative flex items-start justify-between"><div><p className="font-mono text-[9px] uppercase tracking-[.2em] text-[#d6e3d2]/70">Right now</p><h2 className="mt-3 text-[25px] font-semibold tracking-[-.06em]">{city.status}</h2></div><CloudSun size={64} strokeWidth={1.3} className="text-[#f0bf4e]" /></div>
                <div className="relative mt-9 flex items-start"><span className="text-[100px] font-semibold leading-[.75] tracking-[-.13em]">{city.temp}</span><span className="ml-3 mt-1 text-xl text-[#d6e3d2]/70">°C</span></div>
                <p className="absolute bottom-7 left-7 text-[12px] text-[#d6e3d2]/75 sm:left-9">Feels like 18° · Daylight</p>
                <div className="absolute bottom-7 right-7 flex gap-4 font-mono text-[10px] text-[#eff2df]/80 sm:right-9"><span className="flex items-center gap-1.5"><Wind size={13} className="text-[#f0bf4e]" />12 km/h</span><span className="flex items-center gap-1.5"><Droplets size={13} className="text-[#f0bf4e]" />64%</span></div>
              </div>
              <div className="rounded-[26px] border p-7 sm:p-9" style={{ borderColor: "#d8d9d0", background: "#f7f5ef" }}>
                <div className="flex items-start justify-between"><div><p className="font-mono text-[9px] uppercase tracking-[.2em]" style={{ color: "#7b8885" }}>A gentle day ahead</p><h2 className="mt-2 text-[25px] font-semibold tracking-[-.06em]">Sunrise to sunset</h2></div><Sunrise size={20} style={{ color: "#d99e3d" }} /></div>
                <div className="relative mt-10 h-20"><div className="absolute left-0 right-0 top-[58px] h-px bg-[#d9ddd5]" /><div className="absolute left-[6%] top-[15px] h-[45px] w-[88%] rounded-[100%_100%_0_0] border-t border-dashed border-[#d99e3d]" /><div className="absolute top-[7px] h-3.5 w-3.5 -translate-x-1/2 rounded-full bg-[#d99e3d] shadow-[0_0_0_6px_rgba(217,158,61,.14)]" style={{ left: progress }} /><div className="absolute top-[54px] h-2 w-2 -translate-x-1/2 rounded-full bg-[#4f8786]" style={{ left: "36%" }} /></div>
                <div className="flex justify-between font-mono text-[10px]" style={{ color: "#7b8885" }}><span className="flex flex-col gap-1"><span>RISE</span><strong className="font-sans text-[16px] text-[#25393c]">5:48 AM</strong></span><span className="flex flex-col items-end gap-1"><span>SET</span><strong className="font-sans text-[16px] text-[#25393c]">8:35 PM</strong></span></div>
              </div>
            </section>

            <section className="mt-11">
              <div className="mb-4 flex items-baseline justify-between"><h2 className="text-[21px] font-semibold tracking-[-.06em]">Follow the day</h2><span className="font-mono text-[9px] uppercase tracking-[.15em]" style={{ color: "#7b8885" }}>Tap a moment</span></div>
              <div className="overflow-hidden rounded-2xl border" style={{ borderColor: "#d8d9d0", background: "#f7f5ef" }}><div className="flex min-w-[700px]">{hours.map((item, i) => <button key={item.time} onClick={() => setSelectedHour(i)} className="group flex-1 border-r px-2 py-4 text-center transition last:border-0 hover:bg-[#edf0e8]" style={{ borderColor: "#e0e1da", background: selectedHour === i ? "#e9eee6" : "transparent" }}><span className="font-mono text-[9px]" style={{ color: selectedHour === i ? "#3f7d7c" : "#89938e" }}>{item.time}</span><item.Icon size={21} className="mx-auto my-4" style={{ color: selectedHour === i ? "#d99e3d" : "#4f8786" }} /><strong className="text-[17px] tracking-[-.06em]">{item.temp}°</strong><small className="mt-2 block font-mono text-[9px] text-[#4f8786]">{item.rain}% rain</small></button>)}</div></div>
              <div className="mt-3 flex flex-wrap items-center justify-between gap-4 rounded-xl px-4 py-3 font-mono text-[9px]" style={{ background: "#e7ebe4", color: "#71807b" }}><span className="uppercase tracking-[.15em]">Selected moment</span><strong className="font-sans text-[12px] text-[#25393c]">{selected.time} · {selected.temp}° · {selected.rain}% chance of rain</strong><span>Wind {selectedHour > 3 ? "14" : "12"} km/h</span></div>
            </section>

            <section className="mt-11 grid gap-4 lg:grid-cols-[1.3fr_.7fr]">
              <div><div className="mb-4 flex items-baseline justify-between"><h2 className="text-[21px] font-semibold tracking-[-.06em]">The next few days</h2><span className="text-[11px]" style={{ color: "#7b8885" }}>5-day outlook</span></div><div className="overflow-hidden rounded-2xl border" style={{ borderColor: "#d8d9d0", background: "#f7f5ef" }}>{week.map(([day, date, hi, lo, Icon, label], weekIndex) => <div key={date as string} className="grid min-h-[62px] grid-cols-[90px_32px_1fr_70px_45px] items-center gap-3 border-b px-4 last:border-0 sm:grid-cols-[110px_38px_1fr_100px_55px]" style={{ borderColor: "#e2e2db" }}><span className="text-[12px] font-semibold">{day}<small className="mt-1 block font-mono text-[9px] font-normal text-[#89938e]">{date}</small></span><Icon size={21} style={{ color: "#4f8786" }} /><span className="hidden text-[11px] text-[#7b8885] sm:block">{label}</span><span className="font-mono text-[11px]"><b>{hi}°</b><span className="ml-4 text-[#a1aaa5]">{lo}°</span></span><span className="text-right font-mono text-[10px] text-[#4f8786]">{[8, 4, 56, 10, 3][weekIndex]}% <Droplets size={11} className="inline" /></span></div>)}</div></div>
              <div className="rounded-2xl p-6 text-[#f4eddd]" style={{ background: "#29494c" }}><div className="flex items-center justify-between"><p className="font-mono text-[9px] uppercase tracking-[.18em] text-[#d4dfcb]/70">Atmos note</p><Gauge size={16} className="text-[#e5b34b]" /></div><h3 className="mt-5 text-[24px] font-semibold leading-[1] tracking-[-.07em]">A good day for the long way home.</h3><p className="mt-4 text-[12px] leading-relaxed text-[#d4dfcb]/75">Cloud cover arrives late, but the evening stays mild. Visibility is clear through sunset.</p><button className="mt-6 rounded-lg border border-[#d8b762]/50 bg-[#d8b762]/10 px-3 py-2 text-[10px] text-[#e5b34b]">Refresh briefing</button></div>
            </section>
          </div>
        </main>
      </div>
    </div>
  );
}
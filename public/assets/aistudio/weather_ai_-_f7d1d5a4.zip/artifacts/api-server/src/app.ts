import express, { type Express } from "express";
import cors from "cors";
import path from "path";
import fs from "fs";
import pinoHttp from "pino-http";
import router from "./routes";
import { logger } from "./lib/logger";

const app: Express = express();

app.use(
  pinoHttp({
    logger,
    serializers: {
      req(req) {
        return {
          id: req.id,
          method: req.method,
          url: req.url?.split("?")[0],
        };
      },
      res(res) {
        return {
          statusCode: res.statusCode,
        };
      },
    },
  }),
);
app.use(cors());
app.use(express.json());
app.use(express.urlencoded({ extended: true }));

app.use("/api", router);

const candidateStaticPaths = [
  path.resolve(process.cwd(), "artifacts/atmos-weather/dist/public"),
  path.resolve(__dirname, "../../atmos-weather/dist/public"),
  path.resolve(__dirname, "../atmos-weather/dist/public"),
  path.resolve(process.cwd(), "dist/public"),
];

const staticPath = candidateStaticPaths.find((p) => fs.existsSync(p)) || candidateStaticPaths[0];

app.use(express.static(staticPath));
app.use((req, res, next) => {
  if (req.method !== "GET" && req.method !== "HEAD") {
    return next();
  }
  const indexPath = path.join(staticPath, "index.html");
  if (fs.existsSync(indexPath)) {
    res.sendFile(indexPath);
  } else {
    res.status(200).send(`
      <!DOCTYPE html>
      <html>
        <head><title>Atmos Weather</title><meta charset="utf-8"/><meta name="viewport" content="width=device-width, initial-scale=1.0"/></head>
        <body style="font-family:sans-serif;padding:40px;text-align:center;background:#0d1520;color:#fff;">
          <h2>Atmos Weather is initializing...</h2>
          <p>Please refresh in a moment.</p>
        </body>
      </html>
    `);
  }
});

export default app;


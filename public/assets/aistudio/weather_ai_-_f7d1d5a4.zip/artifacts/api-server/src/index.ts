import app from "./app";
import { logger } from "./lib/logger";

const rawPort = process.env.PORT || "3000";
const port = Number(rawPort) || 3000;

const server = app.listen(port, "0.0.0.0", () => {
  logger.info({ port }, `Server listening on http://0.0.0.0:${port}`);
});

server.on("error", (err) => {
  logger.error({ err }, "Error listening on port");
  process.exit(1);
});



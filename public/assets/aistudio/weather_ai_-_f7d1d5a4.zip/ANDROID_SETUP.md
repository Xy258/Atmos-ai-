# Atmos Weather — Android Application Setup Guide

Atmos Weather is configured to run as an Android application in two ways:

---

## Method 1: Instant Installation on Android (PWA / WebAPK) — No App Store Needed

Android natively converts Atmos into a standalone Android app through Chrome, Samsung Internet, Edge, or Brave using Google's **WebAPK** technology:

1. Open your shared deployment URL on your Android phone:
   ```
   https://ais-pre-zroebspeubnb25nsafax5q-836722758609.asia-southeast1.run.app
   ```
2. Tap the **"Get Android App"** / **"Install on Android"** button in the top navigation, or tap the **⋮ (three dots)** menu in Chrome.
3. Select **"Install app"** or **"Add to Home screen"**.
4. Android will package Atmos onto your home screen and app launcher:
   - **Real Android app icon** (custom squircle maskable icon with sun & atmospheric cloud)
   - **Standalone fullscreen window** (no browser address bar or bottom controls)
   - **Offline caching**: Cached forecasts and app shell load instantly even without signal
   - **Hardware geolocation**: Native GPS positioning for live location forecasts

---

## Method 2: Compile a Standalone Android APK / AAB (Capacitor)

If you need a standalone `.apk` for sideloading or an `.aab` bundle to publish to Google Play:

### Prerequisites
- Node.js 18+ & npm
- Android Studio with Android SDK 34+

### Build Steps

1. **Install Capacitor Dependencies**:
   ```bash
   npm install -D @capacitor/core @capacitor/cli @capacitor/android
   ```

2. **Build Web Production Assets**:
   ```bash
   npm run build
   ```

3. **Initialize Android Platform**:
   ```bash
   npx cap add android
   ```

4. **Sync Web Assets & Launch Android Studio**:
   ```bash
   npx cap sync
   npx cap open android
   ```

5. **Generate APK**:
   In Android Studio, click **Build** > **Build Bundle(s) / APK(s)** > **Build APK(s)**.
   The resulting APK will be saved at:
   `android/app/build/outputs/apk/debug/app-debug.apk`

---

## Configured PWA & Android Assets

- **Web App Manifest**: `public/manifest.webmanifest` & `public/manifest.json`
- **Android Home Icons**:
  - `public/pwa-192x192.png` (Standard launcher)
  - `public/pwa-512x512.png` (Hi-res splash & Play Store)
  - `public/pwa-maskable-512x512.png` (Android adaptive squircle/circle safe zone)
- **Service Worker**: `public/sw.js` with Stale-While-Revalidate caching
- **Capacitor Config**: `capacitor.config.json`

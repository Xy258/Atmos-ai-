import fs from "node:fs";
import path from "node:path";
import { execSync } from "node:child_process";

const clientDistIndex = path.resolve(process.cwd(), "artifacts/atmos-weather/dist/public/index.html");
if (!fs.existsSync(clientDistIndex)) {
  console.log("Compiling client app bundle before startup...");
  try {
    execSync("npm run build --workspace=@workspace/atmos-weather", { stdio: "inherit" });
  } catch (err) {
    console.error("Failed to build client app:", err);
  }
}

const distFile = path.resolve(process.cwd(), "artifacts/api-server/dist/index.mjs");

if (!fs.existsSync(distFile)) {
  console.log("Compiling API server bundle before startup...");
  try {
    execSync("node ./artifacts/api-server/build.mjs", { stdio: "inherit" });
  } catch (err) {
    console.error("Failed to build api-server:", err);
    process.exit(1);
  }
}

await import("./artifacts/api-server/dist/index.mjs");
